//
//  ViewController.h
//  StartUp Project
//
//  Created by cetauri on 12. 10. 30..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    IBOutlet UIButton *createButton;
    IBOutlet UIButton *queryButton;
    IBOutlet UILabel *label;
}

- (IBAction)createButtonClick:(id)sender;
- (IBAction)queryButtonClick:(id)sender;
@end
