//
//  ViewController.m
//  StartUp Project
//
//  Created by cetauri on 12. 10. 30..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import "ViewController.h"
#import "BaasClient.h"

@interface ViewController (){
    NSString *_entityUUID;
}

@end

@implementation ViewController


- (IBAction)createButtonClick:(id)sender{
    BaasClient *client = [BaasClient createInstance];
    
    NSDictionary *entity = @{@"greeting": @"Hello!! baas.io!!"};
    BaasIOResponse *response = [client createEntity:@"foo" entity:entity];

    if(response.transactionState == kUGClientResponseSuccess){
        label.text = @"Create Success!!";
    } else {
        label.text = @"Create failure!!";
    }
    
    _entityUUID = [[[response.rawResponse objectForKey:@"entities"]objectAtIndex:0]objectForKey:@"uuid"];
    
    NSLog(@"response : %@", response.rawResponse);
    
}
- (IBAction)queryButtonClick:(id)sender{
    BaasClient *client = [BaasClient createInstance];
    BaasIOResponse *response = [client readEntity:@"foo" entityID:_entityUUID];
    
    if(response.transactionState == kUGClientResponseSuccess){
        label.text = @"Query Success!!";
    } else {
        label.text = @"Query failure!!";
    }
    
    NSLog(@"response : %@", response.rawResponse);
}


@end
