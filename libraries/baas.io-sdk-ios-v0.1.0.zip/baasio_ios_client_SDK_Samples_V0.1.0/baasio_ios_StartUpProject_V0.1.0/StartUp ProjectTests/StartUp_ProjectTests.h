//
//  StartUp_ProjectTests.h
//  StartUp ProjectTests
//
//  Created by cetauri on 12. 10. 30..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface StartUp_ProjectTests : SenTestCase

@end
