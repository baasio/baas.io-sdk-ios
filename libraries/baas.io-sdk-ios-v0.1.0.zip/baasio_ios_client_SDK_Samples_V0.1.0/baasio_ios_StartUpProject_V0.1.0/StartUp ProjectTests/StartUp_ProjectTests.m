//
//  StartUp_ProjectTests.m
//  StartUp ProjectTests
//
//  Created by cetauri on 12. 10. 30..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import "StartUp_ProjectTests.h"

@implementation StartUp_ProjectTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in StartUp ProjectTests");
}

@end
