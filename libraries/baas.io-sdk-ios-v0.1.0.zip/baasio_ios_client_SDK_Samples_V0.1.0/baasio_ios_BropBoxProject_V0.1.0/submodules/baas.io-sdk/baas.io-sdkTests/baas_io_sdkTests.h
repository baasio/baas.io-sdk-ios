//
//  baas_io_sdkTests.h
//  baas.io-sdkTests
//
//  Created by cetauri on 12. 10. 25..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface baas_io_sdkTests : SenTestCase

@end
