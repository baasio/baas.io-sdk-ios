//
//  BaasQuery.m
//  baas.io-sdk
//
//  Created by cetauri on 12. 10. 25..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import "BaasQuery.h"

@implementation BaasQuery

@end
