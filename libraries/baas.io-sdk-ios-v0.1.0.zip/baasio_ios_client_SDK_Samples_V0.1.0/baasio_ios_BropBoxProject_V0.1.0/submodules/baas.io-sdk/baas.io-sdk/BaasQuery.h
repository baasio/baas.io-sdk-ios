//
//  BaasQuery.h
//  baas.io-sdk
//
//  Created by cetauri on 12. 10. 25..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import "UGQuery.h"

@interface BaasQuery : UGQuery

@end
