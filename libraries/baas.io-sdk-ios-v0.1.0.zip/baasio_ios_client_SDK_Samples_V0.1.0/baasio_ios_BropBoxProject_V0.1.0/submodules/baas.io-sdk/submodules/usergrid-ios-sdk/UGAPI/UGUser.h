#import <Foundation/Foundation.h>

@interface UGUser : NSObject

@property (nonatomic, retain) NSString *username;
@property (nonatomic, retain) NSString *email;
@property (nonatomic, retain) NSString *uuid;
@property (nonatomic, retain) NSString *picture;

@end
