//
//  UGUser.m
//  testproject1
//
//  Created by Donica Patel on 3/2/12.
//  Copyright (c) 2012 Apigee Corporation. All rights reserved.
//

#import "UGUser.h"

@implementation UGUser

@synthesize username;
@synthesize email;
@synthesize uuid;
@synthesize picture;

@end
