
Sample project with Usergrid iOS client library.

Client library is in UGAPI sub-project. Add this folder to your projects.