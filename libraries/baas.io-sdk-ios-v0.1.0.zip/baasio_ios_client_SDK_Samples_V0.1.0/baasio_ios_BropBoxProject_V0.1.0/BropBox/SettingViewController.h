//
//  SettingViewController.h
//  BropBox
//
//  Created by cetauri on 12. 10. 17..
//  Copyright (c) 2012년 kth. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>

@end
